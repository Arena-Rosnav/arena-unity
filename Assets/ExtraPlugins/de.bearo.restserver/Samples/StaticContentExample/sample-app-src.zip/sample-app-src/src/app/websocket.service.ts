import {Injectable} from "@angular/core";
import {Observable, Observer} from 'rxjs';
import {AnonymousSubject} from 'rxjs/internal/Subject';
import {Subject} from 'rxjs';
import {map} from 'rxjs/operators';

const CHAT_URL = "/websocket/cube_updates";

export interface Message {
  Position: { x: number, y: number, z: number } | undefined,
  Command: string | undefined,
  Time: string
}

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {
  private subject: AnonymousSubject<MessageEvent> | undefined;
  public messages: Subject<Message>;
  private ws: WebSocket | undefined;

  constructor() {
    let url = window.location + CHAT_URL;
    url = url.replace("http://", "ws://").replace("https://", "ws://")
    //url = "ws://localhost:8080/" + CHAT_URL;
    // replace double slashes with single slash except for http://, https:// or ws://
    url = url.replace(/([^:]\/)\/+/g, "$1");
    console.log("Connecting to server: ", url)
    this.messages = <Subject<Message>>this.connect(url).pipe(
      map(
        (response: MessageEvent): Message => {
          let data = JSON.parse(response.data)
          return data;
        }
      )
    );
  }

  public connect(url: string): AnonymousSubject<MessageEvent> {
    if (!this.subject) {
      this.subject = this.create(url);
      console.log("Successfully connected: " + url);
    }
    return this.subject;
  }

  private create(url: string): AnonymousSubject<MessageEvent> {
    let ws = new WebSocket(url);
    let observable = new Observable((obs: Observer<MessageEvent>) => {
      ws.onmessage = obs.next.bind(obs);
      ws.onerror = obs.error.bind(obs);
      ws.onclose = obs.complete.bind(obs);
      return ws.close.bind(ws);
    });
    let observer: Observer<MessageEvent<any>> = {
      error: function (err: any) {
        console.log("Error while connecting to server: ", err);
        throw err
      },
      complete: function () {
      },
      next: (data: Object) => {
        console.log('Message sent to websocket: ', data);
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify(data));
        }
      }
    };
    return new AnonymousSubject<MessageEvent>(observer, observable);
  }

  close() {
    if (this.ws) {
      this.ws.close();
    }
  }
}
