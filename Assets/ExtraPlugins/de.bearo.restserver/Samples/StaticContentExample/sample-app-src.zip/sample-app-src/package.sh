#!/usr/bin/env bash

#
# Build sample-app.zip.bytes
#

rm -rf dist

ng build

cd dist/sample-app || exit

zip sample-app.zip.bytes ./*

cd ../.. || exit
mv dist/sample-app/sample-app.zip.bytes ../Assets/de.bearo.restserver/Samples/StaticContentExample/

#
# Package up source code
#

echo "Prepare to package source code.."
cd ..
cp -r sample-app sample-app-src

echo "Removing build related directories..."
rm -rf sample-app-src/node_modules
rm -rf sample-app-src/dist
rm -rf sample-app-src/.DS_Store
rm -rf sample-app-src/.git
rm -rf sample-app-src/.idea

echo "Packaging source.."
rm sample-app-src.zip || true
zip -r sample-app-src.zip sample-app-src/*

rm -rf sample-app-src/
mv sample-app-src.zip Assets/de.bearo.restserver/Samples/StaticContentExample/
