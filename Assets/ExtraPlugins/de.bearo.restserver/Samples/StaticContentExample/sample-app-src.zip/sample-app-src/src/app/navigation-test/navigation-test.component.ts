import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation-test',
  templateUrl: './navigation-test.component.html',
  styleUrls: ['./navigation-test.component.css']
})
export class NavigationTestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
